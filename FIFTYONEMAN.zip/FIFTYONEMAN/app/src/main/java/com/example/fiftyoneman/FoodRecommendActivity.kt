package com.example.fiftyoneman

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FoodRecommendActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_recommend)
    }
}