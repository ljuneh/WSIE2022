package com.example.fiftyoneman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.fiftyoneman.databinding.ActivityStudyRecommendBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.auth.User
import com.google.firebase.ktx.Firebase

class StudyRecommendActivity : AppCompatActivity() {

    // 로그아웃 구현을 위한 변수
    var auth : FirebaseAuth ?= null
    var googleSignInClient : GoogleSignInClient ?= null
    val database = Firebase.database
    val myRef = database.getReference("message")
//    val binding by lazy { ActivityMainBinding.inflate(layoutInflater)}
    val binding by lazy { ActivityStudyRecommendBinding.inflate(layoutInflater)}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
//        setContentView(R.layout.activity_study_recommend)

        fun addItem(user: com.example.fiftyoneman.User) {
            val id = myRef.push().key!!
            user.id = id
            myRef.child(id).setValue(user)
        }
        with(binding) {
            btnPost.setOnClickListener {
                val name = editName.text.toString()
                val password = editPassword.text.toString()
                val user = User(name, password)
                addItem(user)
                startActivity(Intent (this@StudyRecommendActivity, FoodRecommendActivity::class.java))
            }
        }

//        myRef.addValueEventListener( object: ValueEventListener {
//            override fun onDataChange(snapshot: DataSnapshot) {
//                binding.textList.setText("")
//                for(item in snapshot.children) {
//                    item.getValue(User::class.java)?.let { user ->
//                        binding.textList.append("${user.name} : ${user. password } \n")
//                    }
//                }
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                print(error.message)
//            }
//        })




//        myRef.setValue("User")
//        myRef.child("Name").setValue("CCK16")
//        myRef.child("Name").setValue("Kolacider")
//        myRef.child("Name").setValue("lm99")

        // 구글 로그아웃을 위해 로그인 세션 가져오기
        var gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // firebaseauth를 사용하기 위한 인스턴스 get
        auth = FirebaseAuth.getInstance()

        // 구글 로그아웃 버튼 ID 가져오기
        var google_sign_out_button = findViewById<Button>(R.id.google_sign_out_button)

        // 구글 로그아웃 버튼 클릭 시 이벤트
        google_sign_out_button.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            googleSignInClient?.signOut()

            var logoutIntent = Intent (this, MainActivity::class.java)
            logoutIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(logoutIntent)
        }

    } //onCreate
}
class User {
    var id:String = ""
    var name:String = ""
    var password: String = ""
    constructor()

    constructor(name:String, password: String) {
        this.name = name
        this. password = password
    }
}
